All function required to run our version of algorith is in CCD_implementation.py file in one class LogRegCCD, rest of file were required for experiments.

In file New_data_run.ipynb you can perform your own experiments on different data.

You can fit your own model and find the best parameters and methods for your case. Full functionalities are described in task requirments or in docstrings of methods in LogRegCCD class.

You need only training and test dataset. 